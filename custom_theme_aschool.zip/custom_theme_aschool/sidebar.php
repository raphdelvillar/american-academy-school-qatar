<div ng-cloak layout="row" layout-xs="column" class="top">
      <center><span style="font-size: 75%"><a style="text-decoration:none;color:#FFFFFF;padding:5px" href="#">Downloads</a></span></center>
      <div flex></div>
      <div flex-gt-md="25" flex-md="30">
        <center>
            <a href="https://www.facebook.com/American-Academy-School-1973764846212746" target="_blank" class="icon-button facebook">
                <i class="icon-facebook fa-facebook"></i><span></span>
            </a>
            <a href="https://www.instagram.com/americanacademyqatar" target="_blank" class="icon-button instagram">
                <i class="icon-instagram fa-instagram"></i><span></span>
            </a>
            <a href="" target="_blank" class="icon-button twitter">
                <i class="icon-twitter fa-twitter"></i><span></span>
            </a>
            <!--
            <a href="" class="icon-button linkedin">
                <i class="icon-linkedin fa-linkedin"></i><span></span>
            </a>
        -->
            <!--
            <a href="https://businesspartnersforum.tumblr.com" target="_blank" class="icon-button tumblr">
                <i class="icon-tumblr fa-tumblr"></i><span></span>
            </a>
        -->
        <a href="https://www.youtube.com/channel/UCCr4Qim9knRGp5wPzAwae6g/videos" target="_blank" class="icon-button youtube">
            <i class="icon-youtube fa-youtube-play"></i><span></span>
        </a>
        <a href="https://join.skype.com/i8w0oCKTuSgC" target="_blank" class="icon-button skype">
            <i class="icon-skype fa-skype"></i><span></span>
        </a>
    </center>
    </div>
</div>

<nav ng-cloak layout="row" class="md-whiteframe-1dp" layout-align="center center" style="height:75px;background-color:#C3393B;z-index:999">
  <div id="primary_nav_wrap" hide-gt-md hide-md>
    <ul>
      <li><a href="#"><i class="material-icons" style="color:#72012C">&#xE8FE;</i></a>
        <ul>
          <li><a href="#">About Us</a>
            <ul>
              <li><a href="">Mission & Vision</a></li>
              <li><a href="">Our Objective</a></li>
              <li><a href="">Association</a></li>
              <li><a href="">Board of Trustees</a></li>
              <li><a href="">Founders Message</a></li>
            </ul>
          </li>
          <li><a href="#">Curriculum</a>
            <ul>
              <li><a href="">Overview</a></li>
              <li><a href="">Curricular Activities</a></li>
            </ul>
          </li>
          <li><a href="#">Admission</a>
            <ul>
              <li><a href="">Overview</a></li>
              <li><a href="">Enrollment Procedure</a></li>
              <li><a href="">Application Form</a></li>
              <li><a href="">Fee Structure</a></li>
            </ul>
          </li>
          <li><a href="#">Parents</a>
            <ul>
              <li><a href="">School Timing</a></li>
              <li><a href="">Uniforms</a></li>
              <li><a href="">School Calendar</a></li>
              <li><a href="">Student Handbook</a></li>
            </ul>
          </li>
          <li><a href="#">Facilities</a>
            <ul>
              <li><a href="">School Library</a></li>
              <li><a href="">Computer Center</a></li>
              <li><a href="">Cafeteria</a></li>
              <li><a href="">Athletic Facilities</a></li>
              <li><a href="">Science Lab</a></li>
              <li><a href="">Play Area</a></li>
            </ul>
          </li>
          <li><a href="#">Our Policies</a>
            <ul>
              <li><a href="">General</a></li>
              <li><a href="">Student Council</a></li>
            </ul>
          </li>
          <li><a href="#">News & Events</a></li>
          <li><a href="#">Gallery</a>
            <ul>
              <li><a href="www.americanacademy.sch.qa/gallery-photo">Photo</a></li>
              <li><a href="www.americanacademy.sch.qa/gallery-video">Video</a></li>
            </ul>
          </li>
          <li><a href="www.americanacademy.sch.qa/contact-us">Contact Us</a></li>
        </ul>
        </li>
      </ul>
    </div>
    <a href="/" flex>
      <!--<img src="<?php echo get_template_directory_uri();?>/assets/logos/bpf_small.png" height="90px" style="margin-top: -12.5px"/>-->  
    </a>
    <div flex="5" flex-gt-md="30" hide-sm hide-xs></div>
    <div id="primary_nav_wrap" layout-padding hide-sm hide-xs>
      <ul>
        <li><a href="#">About Us</a>
          <ul>
            <li><a href="">Mission & Vision</a></li>
            <li><a href="">Our Objective</a></li>
            <li><a href="">Association</a></li>
            <li><a href="">Board of Trustees</a></li>
            <li><a href="">Founders Message</a></li>
          </ul>
        </li>
        <li><a href="#">Curriculum</a>
          <ul>
            <li><a href="">Overview</a></li>
            <li><a href="">Curricular Activities</a></li>
          </ul>
        </li>
        <li><a href="#">Admission</a>
          <ul>
            <li><a href="">Overview</a></li>
            <li><a href="">Enrollment Procedure</a></li>
            <li><a href="">Application Form</a></li>
            <li><a href="">Fee Structure</a></li>
          </ul>
        </li>
        <li><a href="#">Parents</a>
          <ul>
            <li><a href="">School Timing</a></li>
            <li><a href="">Uniforms</a></li>
            <li><a href="">School Calendar</a></li>
            <li><a href="">Student Handbook</a></li>
          </ul>
        </li>
        <li><a href="#">Facilities</a>
          <ul>
            <li><a href="">School Library</a></li>
            <li><a href="">Computer Center</a></li>
            <li><a href="">Cafeteria</a></li>
            <li><a href="">Athletic Facilities</a></li>
            <li><a href="">Science Lab</a></li>
            <li><a href="">Play Area</a></li>
          </ul>
        </li>
        <li><a href="#">Our Policies</a>
          <ul>
            <li><a href="">General</a></li>
            <li><a href="">Student Council</a></li>
          </ul>
        </li>
        <li><a href="#">News & Events</a></li>
        <li><a href="#">Gallery</a>
          <ul>
            <li><a href="www.americanacademy.sch.qa/gallery-photo">Photo</a></li>
            <li><a href="www.americanacademy.sch.qa/gallery-video">Video</a></li>
          </ul>
        </li>
        <li><a href="www.americanacademy.sch.qa/contact-us">Contact Us</a></li>
      </ul>
    </div>
  </div>
</nav>

<script>
$(window).scroll(function(){
    if ($(window).scrollTop() >= 100) {
       $('nav').addClass('fixed-header');
       $('nav').removeClass('relative-header');
    }
    else {
       $('nav').removeClass('fixed-header');
       $('nav').addClass('relative-header');
    }
});
</script>

<div id="overlay" style="z-index:998">
    <video class="visible-desktop" style="width:100%;" loop muted autoplay>
        <source src="<?php echo get_template_directory_uri();?>/assets/videos/aas.mp4" type="video/mp4">
            <source src="<?php echo get_template_directory_uri();?>/assets/videos/aas.webm" type="video/webm">
            </video>
            <img id="hero-pic" class="hidden-desktop" src="<?php echo get_template_directory_uri();?>/assets/asbanner.jpeg" alt="">
        </div>
        <script>
            $(document).ready(function () {
                $(window).on('load scroll', function () {
                    var scrolled = $(this).scrollTop();
                    $('#title').css({
                'transform': 'translate3d(0, ' + -(scrolled * 0.2) + 'px, 0)', // parallax (20% scroll rate)
                'opacity': 1 
            });
            $('#hero-vid').css('transform', 'translate3d(0, ' + -(scrolled * 0.25) + 'px, 0)'); // parallax (25% scroll rate)
        });
                
        // video controls
        $('#state').on('click', function () {
            var video = $('#hero-vid').get(0);
            var icons = $('#state > span');
            $('#overlay').toggleClass('fade');
            if (video.paused) {
                video.play();
                icons.removeClass('fa-play').addClass('fa-pause');
            } else {
                video.pause();
                icons.removeClass('fa-pause').addClass('fa-play');
            }
        });
    });
</script>
<div ng-cloak layout="row" class="md-whiteframe-1dp" layout-align="center center" style="height: 35px; position:relative; background-color:#C3393B;opacity:0.9;z-index:998">
    <center hide-xs hide-sm><marquee style="color:#FFFFFF">Welcome to the American Academy School!</marquee></center>
</div>