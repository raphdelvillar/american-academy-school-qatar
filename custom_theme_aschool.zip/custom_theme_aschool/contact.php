	<!--/* Template Name: Contact_Us */-->
	<?php get_header(); ?>
	<?php get_sidebar(); ?>
	<div style="position:relative;background-color:#FFFFFF;z-index:998">
		<div layout="column" layout-padding>
			<div layout="row" layout-xs="column" layout-sm="column" layout-align="center center">
				<div hide-xs hide-sm flex="5"></div>
				<div flex="45" flex-xs="90" flex-sm="90" layout-padding>	
					<center><h2 style="color:#3B3364">Contact Form</h2></center><br/>
					<ul id="contact-form" style="list-style:none;margin:0;padding:0">
						<?php dynamic_sidebar('widgetcontactform');?>
					</ul><br/><br/><br/><br/><br/><br/>
				</div>
				<div flex="45" flex-xs="90" flex-sm="90" layout-padding style="border-left: 1px solid #C3393B;">
					<center>
						<ul style="list-style:none;margin:0;padding:0">
							<?php dynamic_sidebar( 'widgetmaps' ); ?>
						</ul>
					</center>
					<br/><br/>
					<p class="md-body-1" style="border:0.5px solid #3B3364;font-size:75%">
						<b style="color:#C3393B">American Academy School Qatar</b><br/><br/>
						<i class="icon-contact fa-inbox" style="color:#C3393B"></i> P.O. Box: 22978 Doha , Qatar<br/>
						<i class="icon-contact fa-map-marker" style="color:#C3393B"></i>  Main Building: <i class="icon-contact fa-phone" style="color:#C3393B"></i> 44551278 / 44663241<br/>
						<i class="icon-contact fa-map-marker" style="color:#C3393B"></i>  KG Building: <i class="icon-contact fa-phone" style="color:#C3393B"></i> 44665735/ 44663860<br/>
						<i class="icon-contact fa-envelope-o" style="color:#C3393B"></i> info@americanacademy.sch.qa<br/>
						<i class="fa fa-globe" style="color:#C3393B"></i> www.americanacademy.sch.qa
					</p>
					<p class="md-body-1" style="border:0.5px solid #3B3364;font-size:75%">
						<b style="color:#C3393B">American Academy Kinder Garten</b><br/><br/>
						<i class="icon-contact fa-map-marker" style="color:#C3393B"></i>  Al Thumama, Doha, Qatar<br/>
						<i class="icon-contact fa-map-marker" style="color:#C3393B"></i>  KG Building: <i class="icon-contact fa-phone" style="color:#C3393B"></i> 44665735/44663860<br/>
						<i class="icon-contact fa-envelope-o" style="color:#C3393B"></i> info@americanacademy.sch.qa<br/>
						<i class="fa fa-globe" style="color:#C3393B"></i> www.americanacademy.sch.qa
					</p>
				</div>
				<div hide-xs hide-sm flex="5"></div>
			</div>
		</div>
	</div>
			<?php include "index_footer.php" ?>
			<?php get_footer(); ?>