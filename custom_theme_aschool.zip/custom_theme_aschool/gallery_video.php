	<!--/* Template Name: Gallery_Video */-->
	<?php get_header(); ?>
	<?php get_sidebar(); ?>
	<div style="position:relative;background-color:#FFFFFF;z-index:998">
		<br/>
		<center>
		<h2 style="color:#3B3364">Gallery > Video</h2>
		</center>
		<div layout="row" layout-padding>
			<div flex="5"></div>
			<div flex>
			<ul style="list-style:none;margin:0;padding:0">
				<?php dynamic_sidebar( 'widgetyoutubeplayer' ); ?>
			</ul>
			</div>
			<div flex="5"></div>
		</div>
	</div>
			<?php include "index_footer.php" ?>
			<?php get_footer(); ?>