<div ng-cloak style="background-color:#C3393B;color:#ffffff;position:relative;opacity: 0.95">
  <center>
  <table hide-gt-md layout-padding>
    <tr>
      <td><i class="icon-contact fa-phone" style="font-size:75%;color:#FFFFFF"></i></td>
      <td><span style="font-size:75%" flex-offset="5">+974 4455 1278</span></td>
    </tr>
    <tr>
      <td><i class="icon-contact fa-inbox" style="font-size:75%;color:#FFFFFF"></i></td>
      <td><span style="font-size:75%" flex-offset="5">PO Box 22978, Doha-Qatar</span></td>
    </tr>
    <tr>
      <td><i class="icon-contact fa-fax" style="font-size:75%;color:#FFFFFF"></i></td>
      <td><span style="font-size:75%" flex-offset="5">+974 4466 3241</span></td>
    </tr>
    <tr>
      <td><i class="icon-contact fa-envelope-o" style="font-size:75%;color:#FFFFFF"></i></td>
      <td><span style="font-size:75%" flex-offset="5">info@americanacademy.sch.qa</span></td>
    </tr>
  </table>
  </center>
  <div ng-cloak hide-xs hide-sm hide-md layout="row" layout-xs="column" layout-sm="column" flex>
    <div flex-offset="10" flex="20" flex-xs="100" flex-sm="100">
      <center>
      <p style="font-size:75%;color:#FFFFFF">
      <i class="icon-contact fa-phone" style="color:#FFFFFF"></i>
      <span flex-offset="5">+974 4455 1278</span>
      </p>
      </center>
    </div>
    <div flex="20" flex-xs="100" flex-sm="100">
      <center>
      <p style="font-size:75%;color:#FFFFFF">
      <i class="icon-contact fa-inbox" style="color:#FFFFFF"></i>
      <span flex-offset="5">PO Box 22978, Doha - Qatar</span>
      </p>
      </center>
    </div>
    <div flex="20" flex-xs="100" flex-sm="100">
      <center>
      <p style="font-size:75%;color:#FFFFFF">
      <i class="icon-contact fa-fax" style="color:#FFFFFF"></i>
      <span flex-offset="5">
      +974 4466 3241
      </span>
      </p>
      </center>
    </div>
    <div flex="20" flex-xs="100" flex-sm="100">
      <center>
      <p style="font-size:75%;color:#FFFFFF">
      <i class="icon-contact fa-envelope-o" style="color:#FFFFFF"></i>
      <span flex-offset="5">
      info@americanacademy.sch.qa
      </span>
      </p>
      </center>
    </div>
  </div>
</div>
<div show-md show-gt-md style="background-color:#000000;color:#ffffff;position:relative;">
  <div layout="row" layout-xs="column" layout-sm="column" flex>
    <div flex="25" flex-xs="100" flex-sm="100">
      <center>
        <p style="color:#FFFFFF" class="md-body-1">
          &copy 2017 American Academy School
        </p>
      </center>
    </div>
    <div flex="40"></div>
    <div flex>
      <center>
        <p style="color:#FFFFFF" class="md-body-1">Designed and Developed by <a style="text-decoration:underline;color:#FFFFFF" href="http://www.businesspartnersforum.com" target="_blank">www.businesspartnersforum.com</a></p>
      </center>
    </div>
  </div>
</div>