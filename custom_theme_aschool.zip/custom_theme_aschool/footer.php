<?php wp_footer(); ?>
  <!--
  <div show-md show-gt-md style="background-color: #000000;color: #ffffff;position:fixed;">
    <div layout="row" layout-xs="column" layout-sm="column" flex>
      <div flex="75" flex-xs="100" flex-sm="100">
        <center>

          <marquee loop="true" direction="left" scrollamount="2" class="footer">
            <p style="font-size:75%">
              <img style="vertical-align:middle" src="<?php //echo get_template_directory_uri();?>/assets/qatar-flag.jpg" alt="flag" width="32"/> 
              Together, We Serve Better
            </p>
          </marquee>  

        </center>
      </div>
      <div flex>
        <center>
          <p>&copy businesspartnersforum 2017</p>
        </center>
      </div>
    </div>
  -->
    <!-- Custom Scripts -->
    <script src="<?php echo get_template_directory_uri();?>/custom/init.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/custom/factory.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/custom/directive.js"></script>

    <script src="<?php echo get_template_directory_uri();?>/custom/bulletin.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/custom/tinycarousel.js"></script>

    <script>
      $(document).ready(function(){
        $('nav').addClass('relative-header');
      });
    </script>
  </body>
  </html>