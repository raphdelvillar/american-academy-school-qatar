	<!--/* Template Name: Gallery_Photo */-->
	<?php get_header(); ?>
	<?php get_sidebar(); ?>
	<div style="position:relative;background-color:#FFFFFF;z-index:998">	
		<br/>
		<center>
		<h2 style="color:#3B3364">Gallery > Photo</h2>
		<ul style="list-style:none;margin:0;padding:0">
			<?php dynamic_sidebar( 'widgetinstagramfeed' ); ?>
		</ul>
		</center>
	</div>
			<?php include "index_footer.php" ?>
			<?php get_footer(); ?>