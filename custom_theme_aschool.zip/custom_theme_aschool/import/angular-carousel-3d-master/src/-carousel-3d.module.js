(function () {
    'use strict';

    angular
        .module('angular-carousel-3d', [
            'swipe'
        ]);


})();
