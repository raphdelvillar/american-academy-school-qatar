    <?php get_header(); ?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/style/index.css">
	<?php get_sidebar(); ?>
	<div style="position:relative;background-color:#FFFFFF;z-index:998">
		<br/>
		<center>
		<div layout-xs="column">
			<md-button class="md-primary" style="border:1px solid #3B3364">Apply Online</md-button>
			<md-button class="md-primary" style="border:1px solid #3B3364">Payments</md-button>
			<md-button class="md-primary" style="border:1px solid #3B3364">Exams</md-button>
			<md-button class="md-primary" style="border:1px solid #3B3364">Calendar</md-button>
			<md-button class="md-primary" style="border:1px solid #3B3364">Results</md-button>
		</div>
		</center>
		<div layout="column" layout-align="center center" layout-padding>
			<center>
				<h2 style="color:#3B3364">The American Academy School</h2></center><br/>
				<img src="<?php echo get_template_directory_uri();?>/assets/logos/logo.png" height="200" width="250">
				<p align="center" style="font-size:85%">
					The American Academy School was founded in 2000 and is under the supervision and guidance of the Supreme Council. 
					<br/><br/>It follows internationally enriched American curriculum, serving a multicultural student body. 
					<br/><br/>It comprises of Kindergarten, Primary, Junior High and High School.
				</p>
			<center>
		</div>
	</div>
	<div style="position:relative;background-image:url('wp-content/themes/custom_theme_aschool/assets/school2-1.jpg');background-repeat:no-repeat;background-size:cover;z-index:3">
		<br/>
		<?php include "pages/simple-portfolio-page/students.html" ?>
		<br/>
	</div>
	<div style="position:relative;background-color:#FFFFFF;z-index:3">
		<div layout="row" layout-xs="column" layout-sm="column" layout-padding>
			<div flex="5"></div>
			<center>
			<div flex="90" flex-xs="100" flex-sm="100">
				<center><h2 style="color:#3B3364">Founder's Message</h2></center><br/>
				<div layout="row" layout-xs="column" layout-sm="column">
					<img flex="45" hide-xs hide-sm src="<?php echo get_template_directory_uri();?>/assets/logos/logo.png" height="150" class="img-circle" style="margin-top:25px">

					<center>
						<img flex="90" hide-md hide-gt-md src="<?php echo get_template_directory_uri();?>/assets/logos/logo.png">
					</center>
					<p flex-offset="5" align="justify" style="font-size:75%">
						Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce felis elit, feugiat et nunc eu, fermentum hendrerit turpis. Vivamus sodales, metus hendrerit pulvinar ornare, diam tellus tristique lectus, vel maximus felis ex id tortor. Donec ex eros, lobortis non pellentesque in, gravida et tellus. Sed ultrices cursus justo, eget sagittis quam interdum sit amet. Ut tristique nisi lorem, ac auctor dolor pulvinar mollis. Vivamus nec iaculis eros. Interdum et malesuada fames ac ante ipsum primis in faucibus. Donec nec ipsum nibh. Pellentesque vel libero id urna semper egestas. Phasellus odio dolor, porta a convallis sit amet, ultricies sed enim. Nulla sollicitudin ex efficitur, fermentum purus sit amet, pulvinar dui. Mauris quis leo sed orci scelerisque ornare ut vel eros. Morbi ac dapibus libero. Aliquam erat volutpat.
						<br/><br/>
						Suspendisse potenti. Nam condimentum arcu a mauris molestie, sed tempor est rutrum. In maximus risus ut erat facilisis, vel suscipit velit molestie. Morbi molestie placerat condimentum. Quisque et suscipit neque. Phasellus id placerat tortor, nec consectetur metus. Quisque euismod semper justo et volutpat. Morbi dapibus, odio ac imperdiet eleifend, massa erat porta mauris, nec semper nisl augue in nulla. Integer pharetra mauris et sem faucibus fermentum. Nulla felis ante, molestie et libero quis, gravida tempor ligula. Nulla accumsan metus non nulla posuere facilisis. Phasellus blandit imperdiet elementum. Nunc felis libero, rhoncus ac magna in, efficitur ultricies eros.
					</p>
				</div>
			</div>
			</center>
			<div flex="5"></div>
		</div>
		<br/>
		<center>
			<center><h2 style="color:#3B3364">School at a Glance</h2></center><br/>
			<div ng-controller="Tinycarousel" style="width:95%" class="students">
				<div ng-repeat="item in home_students" class="hvr-grow">
					<img src="{{item.src}}" height="200" width="200"/>
				</div>
			</div>
			<br/>
		</center>
		<script type="text/javascript">
			$(document).ready(function(){
				$('.students').slick({
					dots: true,
					infinite: true,
					speed: 700,
					autoplay:true,
					autoplaySpeed: 2000,
					arrows:true,
					slidesToShow: 6,
					slidesToScroll: 1,
					responsive: [
					{
						breakpoint: 1024,
						settings: {
							slidesToShow: 3,
							slidesToScroll: 3,
							infinite: true,
							dots: true
						}
					},
					{
						breakpoint: 600,
						settings: {
							slidesToShow: 2,
							slidesToScroll: 2,
							dots: false
						}
					},
					{
						breakpoint: 480,
						settings: {
							slidesToShow: 1,
							slidesToScroll: 1,
							dots: false
						}
					}
					]
				});
			});
		</script>
		<div layout="column" layout-padding>
			<div layout="row" layout-xs="column" layout-sm="column" layout-align="center center">
				<div hide-xs hide-sm flex="5"></div>
				<div flex="45" flex-xs="90" flex-sm="90" layout-padding>
					<center>
						<ul style="list-style:none;margin:0;padding:0;border:1px solid black">
							<?php dynamic_sidebar( 'widgetmaps' ); ?>
						</ul>
					</center>
				</div>
				<div flex="45" flex-xs="90" flex-sm="90" style="background-color:#3B3364;" layout-padding>	
					<center>
					<h2 style="color:#FFFFFF">Latest News</h2>
					<md-divider style="border-color:#FFFFFF"></md-divider>
					</center>
					<marquee direction="up" SCROLLAMOUNT="2" flex id="home_bulletin" style="overflow:hidden;height:297px" layout-padding>
						<md-list>
							<div>
								<div flex="25" flex-xs="100" flex-sm="100">
									<img src="<?php echo get_template_directory_uri();?>/assets/tng1.jpg" class="md-avatar" height="125" width="125"/>
								</div>
								<p class="md-body-1" flex="50" flex-xs="100" flex-sm="100" style="color:#FFFFFF;font-size:75%">
									<b>Sample Title 1</b>
								</p>
								<p align="justify" class="md-body-1" style="color:#FFFFFF;font-size:75%;white-space:pre-line">
									Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce felis elit, feugiat et nunc eu, fermentum hendrerit turpis. Vivamus sodales, metus hendrerit pulvinar ornare, diam tellus tristique lectus, vel maximus felis ex id tortor.
								</p>
								<div layout="row">
				                   <div flex></div>
				                   <p style="color:#FFFFFF;font-size:75%;cursor:pointer">
				                       <b>Read More...</b>
				                   </p>
			                   </div>
								<md-divider style="border-color:#FFFFFF"></md-divider>
							</div>
							<br/>
							<div>
								<div flex="25" flex-xs="100" flex-sm="100">
									<img src="<?php echo get_template_directory_uri();?>/assets/tng1.jpg" class="md-avatar" height="125" width="125"/>
								</div>
								<p class="md-body-1" flex="50" flex-xs="100" flex-sm="100" style="color:#FFFFFF;font-size:75%">
									<b>Sample Title 2</b>
								</p>
								<p align="justify" class="md-body-1" style="color:#FFFFFF;font-size:75%;white-space:pre-line">
									Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce felis elit, feugiat et nunc eu, fermentum hendrerit turpis. Vivamus sodales, metus hendrerit pulvinar ornare, diam tellus tristique lectus, vel maximus felis ex id tortor.
								</p>
								<div layout="row">
				                   <div flex></div>
				                   <p style="color:#FFFFFF;font-size:75%;cursor:pointer">
				                       <b>Read More...</b>
				                   </p>
			                   </div>
								<md-divider style="border-color:#FFFFFF"></md-divider>
							</div>
							<br/>
							<div>
								<div flex="25" flex-xs="100" flex-sm="100">
									<img src="<?php echo get_template_directory_uri();?>/assets/tng1.jpg" class="md-avatar" height="125" width="125"/>
								</div>
								<p class="md-body-1" flex="50" flex-xs="100" flex-sm="100" style="color:#FFFFFF;font-size:75%">
									<b>Sample Title 3</b>
								</p>
								<p align="justify" class="md-body-1" style="color:#FFFFFF;font-size:75%;white-space:pre-line">
									Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce felis elit, feugiat et nunc eu, fermentum hendrerit turpis. Vivamus sodales, metus hendrerit pulvinar ornare, diam tellus tristique lectus, vel maximus felis ex id tortor.
								</p>
								<div layout="row">
				                   <div flex></div>
				                   <p style="color:#FFFFFF;font-size:75%;cursor:pointer">
				                       <b>Read More...</b>
				                   </p>
			                   </div>
								<md-divider style="border-color:#FFFFFF"></md-divider>
							</div>
						</md-list>
					</marquee>
				</div>
				<div hide-xs hide-sm flex="5"></div>
			</div>
		</div>
		<br/>
		<center>
			<h2 style="color:#3B3364">Our Campus</h2><br/>
			<div ng-controller="Tinycarousel" style="width:95%" class="branches">
				<div ng-repeat="item in home_branches" class="hvr-grow">
					<img src="{{item.src}}" height="200" width="200"/>
				</div>
			</div>
			<br/>
		</center>
		<script type="text/javascript">
			$(document).ready(function(){
				$('.branches').slick({
					dots: true,
					infinite: true,
					speed: 700,
					autoplay:true,
					autoplaySpeed: 2000,
					arrows:true,
					slidesToShow: 6,
					slidesToScroll: 1,
					responsive: [
					{
						breakpoint: 1024,
						settings: {
							slidesToShow: 3,
							slidesToScroll: 3,
							infinite: true,
							dots: true
						}
					},
					{
						breakpoint: 600,
						settings: {
							slidesToShow: 2,
							slidesToScroll: 2,
							dots: false
						}
					},
					{
						breakpoint: 480,
						settings: {
							slidesToShow: 1,
							slidesToScroll: 1,
							dots: false
						}
					}
					]
				});
			});
		</script>
		<br/>
		<center>
		<h2 style="color:#3B3364">Follow us on Instagram</h2>
		<ul style="list-style:none;margin:0;padding:0">
			<?php dynamic_sidebar( 'widgetinstagramfeed' ); ?>
		</ul>
		</center>
	</div>
	<?php include "index_footer.php" ?>
<?php get_footer(); ?>