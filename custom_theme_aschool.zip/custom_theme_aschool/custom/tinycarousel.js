app.controller('Tinycarousel', function($scope, $log){
	$scope.home_branches = [
		{
			'src': 'wp-content/themes/custom_theme_aschool/assets/logos/custom/1.png'
		},
		{
			'src': 'wp-content/themes/custom_theme_aschool/assets/logos/custom/2.png'
		},
		{
			'src': 'wp-content/themes/custom_theme_aschool/assets/logos/custom/3.png'
		}
	]

	$scope.home_students = [
		{
			'src': 'wp-content/themes/custom_theme_aschool/assets/home/1.jpg'
		},
		{
			'src': 'wp-content/themes/custom_theme_aschool/assets/home/2.jpg'
		},
		{
			'src': 'wp-content/themes/custom_theme_aschool/assets/home/3.jpg'
		},
		{
			'src': 'wp-content/themes/custom_theme_aschool/assets/home/4.jpg'
		},
		{
			'src': 'wp-content/themes/custom_theme_aschool/assets/home/5.jpg'
		},
		{
			'src': 'wp-content/themes/custom_theme_aschool/assets/home/6.jpg'
		},
		{
			'src': 'wp-content/themes/custom_theme_aschool/assets/home/7.jpg'
		},
		{
			'src': 'wp-content/themes/custom_theme_aschool/assets/home/8.jpg'
		},
		{
			'src': 'wp-content/themes/custom_theme_aschool/assets/home/9.jpg'
		},
		{
			'src': 'wp-content/themes/custom_theme_aschool/assets/home/10.jpg'
		},
		{
			'src': 'wp-content/themes/custom_theme_aschool/assets/home/11.jpg'
		},
		{
			'src': 'wp-content/themes/custom_theme_aschool/assets/home/12.jpg'
		},
		{
			'src': 'wp-content/themes/custom_theme_aschool/assets/home/13.jpg'
		},
		{
			'src': 'wp-content/themes/custom_theme_aschool/assets/home/14.jpg'
		},
		{
			'src': 'wp-content/themes/custom_theme_aschool/assets/home/15.jpg'
		},
		{
			'src': 'wp-content/themes/custom_theme_aschool/assets/home/16.jpg'
		}
	]
})