app.controller('Bulletins', function($anchorScroll, $scope, $rootScope, $timeout, $location, $log, $mdDialog){
	$scope.marquee = function(){
		$timeout(function(){
			$('#home_bulletin').marquee({
				duration: 10000,
				direction: 'up',
				pauseOnHover: true,
				startVisible: true,
			});
			$scope.active = true;
		}, 1000)
	}

	$scope.init = function(){
	}

	$scope.marquee();
})