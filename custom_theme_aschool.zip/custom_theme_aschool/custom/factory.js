//FACTORY
/* 
#sample post
app.factory('Action', function($http, $rootScope){
	return {
	  action: function(data){
	  	return $http({
	  		method: 'POST',
	  		url: $rootScope.url + '/',
	  		headers: { 'Content-Type' : 'application/x-www-form-urlencoded' },
	  		data: $.param(data)
	  	});
	  }
	}
});
#sample file upload
app.factory('FileUpload', function($http, $rootScope){
	return {
	  fileupload : function(data){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/',
				headers: { 'Content-Type' : undefined },
				data: data
			})
	  },
	}
});
*/