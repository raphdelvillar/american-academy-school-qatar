//DIRECTIVE
//FILE INPUT
app.directive("xdHref", function() {
  return function linkFn (scope, elem, attrs) {
     scope.$watch(attrs.xdHref, function(newVal) {
       newVal && elem.attr("href", newVal);
     });
  };
})
app.directive("inputFiles", function($parse) {
  return function linkFn (scope, elem, attrs) {
    elem.on("change", function (e) {
      var inputFilesGetter = $parse(attrs.inputFiles);
      var inputFilesSetter = inputFilesGetter.assign;
      inputFilesSetter(scope, e.target.files);
      scope.$apply();
    });
  };
})
app.directive("backImg", function(){
    return function(scope, element, attrs){
        attrs.$observe("backImg", function(value) {
            element.css({
                "background-image": "url(" + value +")"
            });
        });
    };
});