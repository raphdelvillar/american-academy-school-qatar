<!DOCTYPE html>
<html lang="en">

<script>
/*
var cssRule =
    "color: #FF0000;" +
    "font-size: 60px;" +
    "font-weight: bold;" +
    "text-shadow: 1px 1px 5px rgb(249, 162, 34);" +
    "filter: dropshadow(color=rgb(249, 162, 34), offx=1, offy=1);";
console.log("%cStop!", cssRule);
setTimeout(console.log.bind(console, '%cYou are not allowed to access the console', 'color: #000000;'), 0);
window.console.log = function(){
    window.console.log = function() {
        return false;
    }
}

$(document).ready(function() {
    $(document)[0].oncontextmenu = function() { return false; }
    $(document).mousedown(function(e) {
        if( e.button == 2 ) {
            return false;
        } else {
            return true;
        }
    });
});
*/
</script>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!--<meta name="viewport" content="width=device-width, initial-scale=1">-->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
    <meta name="description" content="">
    <meta name="author" content="raphdelvillar@gmail.com">

    <title>American Academy School</title>
    <link rel="shortcut icon" href="<?php echo get_template_directory_uri();?>/assets/logos/android-icon-36x36.png" type="image/x-icon">
    
    <!-- Angular Material style sheet -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/angular-material/1.1.4/angular-material.min.css">
    <!-- Angular Material Icons -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-mousewheel/3.1.13/jquery.mousewheel.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
    
    <!-- CUSTOM STYLESHEETS -->
    <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>">
    <link rel='stylesheet prefetch' href='https://netdna.bootstrapcdn.com/font-awesome/3.1.1/css/font-awesome.css'>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/style/sidebar.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/style/tinycarousel.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.1.20/jquery.fancybox.min.css" />
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/import/angular-carousel-3d-master/dist/carousel-3d.css">

    <link href="<?php echo get_template_directory_uri();?>/import/font-awesome/css/font-awesome.css" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/pages/simple-portfolio-page/css/layout.css">

    <!-- Jquery Slick -->
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri();?>/style/slick.css"/>

    <!-- Angular Material requires Angular.js Libraries -->
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.5.5/angular.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.5.5/angular-animate.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.5.5/angular-aria.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.5.5/angular-messages.min.js"></script>

    <!-- Angular Material Library -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/angular-material/1.1.4/angular-material.min.js"></script>
    
    <!-- Angular Sanitize -->
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/angularjs/1.2.1/angular-sanitize.min.js"></script>

    <!-- jquery tinycarousel -->
    <script type="text/javascript" src="<?php echo get_template_directory_uri();?>/import/tinycarousel/lib/jquery.tinycarousel.js"></script>

    <!-- jquery fancybox -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.1.20/jquery.fancybox.min.js"></script>

    <!-- jquery slick -->
    <script type="text/javascript" src="http://cdn.jsdelivr.net/jquery.slick/1.3.11/slick.min.js"></script>

    <!-- Materialize -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.1/js/materialize.min.js"></script>

    <!-- jquery marquee -->
    <script type="text/javascript" src="//cdn.jsdelivr.net/jquery.marquee/1.4.0/jquery.marquee.min.js"></script>

    <!-- Simple Portfolio Page -->
    <script type="text/javascript" src="<?php echo get_template_directory_uri();?>/pages/simple-portfolio-page/js/jquery.mixitup.min.js"></script>

    <!-- Popup -->
    <!-- Font Awesome CDN -->   
    <script type="text/javascript" src="https://use.fontawesome.com/86b7056105.js"></script>
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Montserrat">

<?php wp_head(); ?>
</head>
<body ng-App="app" ng-controller="initialize" style="overflow-x:hidden">